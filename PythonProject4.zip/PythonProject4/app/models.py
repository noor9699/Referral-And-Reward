from flask_pymongo import PyMongo
from werkzeug.security import generate_password_hash, check_password_hash
from mongoengine import Document, StringField, EmailField, IntField, ReferenceField
from flask import Flask, request, jsonify, session
import datetime
from database import users
import random
import string
mongo = PyMongo()

class User(Document):
    username = StringField(required=True, unique=True)
    email = EmailField(required=True, unique=True)
    mobile_number = IntField(required=True, unique=True)
    password = StringField(required=True)
    confirm_password = StringField(required=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

def create_user(username, email, mobile_number, password, user_id, tag_id, expiry):
    user = {
        'username': username,
        'email': email,
        'mobile_number' : mobile_number,
        'password' : generate_password_hash(password),
        "user_id": user_id,
        "tag_id": tag_id,
        "expiry" : expiry
    }
    return mongo.db.users.insert_one(user)

def get_user(email):
    return mongo.db.users.find_one({"email" : email})

def verify_user(email, password):
    user = get_user(email)
    if user and check_password_hash(user['password'], password):
        return user
    return None

def save_user(user_id, tag_id):
    user_unique_data = {
        "user_id" : user_id,
        "tag_id" : tag_id,
    }
class Referral(Document):
    referrer = ReferenceField(User)
    referred_email = EmailField(required=True)


def reset_password(token, user_id):
    data = request.json
    new_password = data.get("new_password")

    user = users.find_one({"user_id" : user_id})
    if not user:
        return jsonify({"message": "Invalid reset link"}), 404

    tokens = user.get("token")
    expiry = user.get("password_token_expires")
    if token !=  tokens:
        return jsonify({"error": "Unauthorized"}), 404
    if not expiry or datetime.datetime.now() > expiry:
        return jsonify({"message": "Reset link expired"}), 404
    users.update_one({"user_id": user_id}, {"$set": {"password": new_password}})
    users.update_one({"user_id": user_id},{"$unset" : {"token": token, "password_token_expires": expiry}})
    return jsonify({"message": "Password updated successfully!"}), 201

