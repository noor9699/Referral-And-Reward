
routes = {
    "registration" : "/register",
    "login" : "/login/<user_id>",
}