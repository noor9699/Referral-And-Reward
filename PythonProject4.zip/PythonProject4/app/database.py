from pymongo import MongoClient

# try:
#     MONGO_URI = "mongodb://192.168.1.13:27018/"
#     client = MongoClient(MONGO_URI)
#     client.admin.command("ping")
#     db = client["loyalty_program"]
#     users = db["users"]
#     referrals = db["referrals"]
# except Exception as e:
#     print(e)
# print("connected")
MONGO_URI = "mongodb://localhost:27017"
client = MongoClient(MONGO_URI)
client.admin.command("ping")
db = client["LoyaltyProgram"]
users = db["users"]
referrals = db["referrals"]

