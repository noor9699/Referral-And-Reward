import datetime
import uuid
import smtplib
from email.mime.text import MIMEText
from flask import Flask, request, jsonify, session
from flask_jwt_extended import JWTManager, create_access_token, jwt_required
from database import users
import random
import string
app = Flask(__name__)
app.config["JWT_SECRET_KEY"] = "areeba-mujeeb-is-Smart"
jwt = JWTManager(app)

app.config["SESSION_TYPE"] = "filesystem"
app.config["SESSION_PERMANENT"] = False
app.secret_key = "areeba-mujeeb-is-Smart"

def generate_tag_id(first_name, mobile):
    mobile_str = str(mobile)
    name_part = first_name[:3].upper()
    mobile_part = mobile_str[-4:]
    random_part = ''.join(random.choices(string.digits, k=3))
    tag_id = f"{name_part}{mobile_part}{random_part}"
    return tag_id

@app.route("/register", methods = ["POST"])
def register():
    data = request.get_json()
    email = data.get("email")
    username = data.get("username")
    mobile_number = data.get("mobile_number")
    password = data.get("password")
    a = users.find_one({"email" : email, "mobile_number" : mobile_number})

    if a:
        return jsonify({"message" : "Email already registered"})

    access_token = create_access_token(identity=password)
    user_id = f"WE_UID_{users.count_documents({}) + 1}"
    tag_id = generate_tag_id(username, mobile_number)
    session_id = str(uuid.uuid4())
    session['session_id'] = session_id
    session['user_id'] = user_id
    expiry = datetime.datetime.now() + datetime.timedelta(hours=5)

    a = users.insert_one({"user_id" : user_id,
                          "tag_id" : tag_id,
                          "email" : email,
                          "username" : username,
                          "password" : password,
                          "access_token" : access_token,
                          "mobile_number"  : mobile_number,
                          "session_id" : session_id,
                          "expiry" : expiry})
    return jsonify({"message" : "Successfully registered"})

@app.route("/login", methods = ['POST'])
def login():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")
    email = data.get("email")

    session_id = str(uuid.uuid4())
    session['session_id'] = session_id
    access_token = create_access_token(identity=password)
    expiry = datetime.datetime.now() + datetime.timedelta(hours=5)

    if email and password:
        find_email = users.find_one({"email": email, "password": password})
        if not find_email:
            return jsonify(({"message" : "Invalid Credentials"}))
        user = find_email.get("user_id")
        users.find_one_and_update({"user_id" : user},
                                  {"$set" : {"access_token" : access_token,
                                             "session_id" : session_id,
                                             "expiry" : expiry}})
        return jsonify({"message" : "Successfully Logged In"})
    if  username and password:
        find_username = users.find_one({"username": username, "password": password})
        if not find_username:
            return jsonify(({"message" : "Invalid Credentials"}))
        user = find_username.get("user_id")
        users.find_one_and_update({"user_id": user},
                                  {"$set": {"access_token": access_token,
                                            "session_id": session_id,
                                            "expiry": expiry}})
        return jsonify({"message": "Successfully Logged In"})
    return jsonify({"message" : "Not Logged in"})

@app.route("/forgot_password/<user_id>", methods = ['POST'])
def forgot_password(user_id):
    data = request.json
    email = data.get("email")
    current_password = data.get("current_password")
    user = users.find_one({"email" : email})
    if not user:
        return jsonify({"status": "Failure", "message": "Email not found"}), 404
    password_reset_token = str(uuid.uuid4())
    expiry = datetime.datetime.now() + datetime.timedelta(minutes=30)
    users.update_one(
        {"user_id": user_id},
        {"$set": {"token": password_reset_token, "password_token_expires": expiry}},
        upsert=True
    )
    reset_link = f"http://127.0.0.1:4000/reset-password/{password_reset_token}"
    email_body = (f"To change your password click on the link below/n"
                  f"{reset_link}")
    try:
        msg = MIMEText(email_body)
        msg["Subject"] = "Password Reset"
        msg["From"] = "saksheesharma1104@gmail.com"
        msg["To"] = "areebamujeeb309@gmail.com"
        with smtplib.SMTP("smtp.gmail.com", 587) as server:
            server.starttls()
            server.login("areebamujeeb309@gmail.com", "rvph suey zpfl smpw")
            server.sendmail("something3029@gmail.com", email, msg.as_string())
            return jsonify({"message": "Password reset link sent to your email", "reset_token" : reset_link}), 201
    except Exception as e:
        return jsonify({"error": f"Failed to send email: {str(e)}"}), 404

@app.route("/reset_password/<token>/<user_id>", methods = ['POST'])
def reset_password(token, user_id):
    return

@app.route("/logout/<user_id>", methods = ['GET'])
def log_out(user_id):
    find_user = users.find_one({"user_id": user_id})
    session_id = find_user.get("session_id")
    access_token = find_user.get("access_token")
    expiry = find_user.get("expiry")
    user = users.update_one({"user_id": user_id},{"$unset" : {"session_id" : session_id, "access_token" : access_token, "expiry" : expiry}})
    return 'Logged out', 201
if __name__ == "__main__":
    app.run(debug = True, port = 4000)